//Complejidad O(nLogn)

#ifndef __MAXHEAP_H_
#define __MAXHEAP_H_

  #include<vector>
  #include<iostream>
  #include "metodos.h"

  template<class T>
  class MaxHeap {
    private:
      // contiene los elementos del heap
      std::vector<T> data;
      // contiene las ocurrencias de cada llave del heap
      std::vector<int> occurences;
      // capacidad maxima del heap
      int maxSize;
      // tamaño actual del heap   
      int size;
      int parent(int i);
      int left(int i);
      int right(int i);

    public:
      MaxHeap(int capacity);
      ~MaxHeap();
      bool isEmpty();
      int getSize();
      int getCapacity();
      void printMaxHeap();
      void printOccurences();
      void push(T key);
      T top();
      T pop();
      void acomodaAbajo(int);
      int getTopOccurence();
      int checkDupes(T key, int pos);
      void repair(int i);
  };

  template <class T> 
  MaxHeap<T>::MaxHeap(int capacity) {
      std::cout << "--->Creando un MaxHeap: " <<  this << std::endl;
      size = 0;
      maxSize = capacity;
      data.resize(maxSize);
      occurences.resize(maxSize);
  }

  // Se agregó un clear para el vector de ocurrencias
  template <class T> 
  MaxHeap<T>::~MaxHeap() {
      std::cout << "--->Liberando memoria del MaxHeap: " <<  this << std::endl;
      data.clear();
      occurences.clear();
  }
  
  template <class T> 
  bool MaxHeap<T>::isEmpty() {
    return (size <= 0);
  }

  template <class T> 
  int MaxHeap<T>::getSize() {
    return size;
  }

  template <class T> 
  int MaxHeap<T>::getCapacity() {
    return maxSize;
  }

  // Se ajustó para manejar específicamente las IPs
  template <class T> 
  void MaxHeap<T>::printMaxHeap() {
    T val;
    for(int i = 0; i < size; i++) {
      val = data[i];
      cout << val[0] << "." << val[1] << "." << val[2] << "." << val[3] << endl;
    }
  }

  template <class T>
  void MaxHeap<T>::printOccurences() {
    for(int occ : occurences) {
      cout << occ << endl;
    }
  }

  template <class T> 
  int MaxHeap<T>::parent(int i) {
    return (i-1)/2;
  }
  
  template <class T> 
  int MaxHeap<T>::left(int i) {
    return (2*i + 1); 
  }

  template <class T> 
  int MaxHeap<T>::right(int i) {
    return (2*i + 2);
  }

  // Se agregó un manejo de duplicados que a la vez funciona para mantener un conteo de las ocurrencias totales
  // de cada llave. Como el MaxHeap ahora funciona con base al valor de las ocurrencias, hay dos casos en los
  // que debemos preservar las propiedades del MaxHeap en caso de que se violen, entonces ese pedazo de código
  // pasó a su propia función.
  template <class T> 
  void MaxHeap<T>::push(T key) {

    if (size >= maxSize) {
        std::cout << "Overflow: no se puede insertar la llave: " << std::endl;
        return;
    }

    int dup = checkDupes(key, 0);

    if(dup >= 0) {
      occurences[dup]++;
      repair(dup);
      return;
    }
    // Insertamos la nueva llave al final del vector
    data[size] = key;
    occurences[size] = 1;
    repair(size);
    size++;
    // Reparar las propiedades del max heap si son violadas
    
  }

  template <class T> 
  T MaxHeap<T>::top() {
    T result = (T)NULL;
    if (isEmpty()) {
        std::cout << "El MaxHeap está vacio" << std::endl;
        return result;
    }
    return data[0];
  }

  // Se agregó el manejo de datos al vector que maneja las ocurrencias. Toda función que ejecutemos en data,
  // debe ser ejecutada también ahora en occurences para asegurar que correspondan correctamente las posiciones
  // de las llaves con sus ocurrencias.
  template <class T>
  void MaxHeap<T>::acomodaAbajo(int ap){
    int aux = ap;
    int hijos = 2*ap, hijomay;

    while (hijos <= size){
      hijomay = (occurences[hijos]>occurences[hijos+1]) ? hijos : hijos + 1;
      if(occurences[hijomay] > occurences[aux]){
        std::swap(data[aux],data[hijomay]);
        std::swap(occurences[aux],occurences[hijomay]);
        aux = hijomay;
        hijos = 2*aux;
      } else break;
    }
  }

  // Se agregó el manejo de datos al vector que maneja las ocurrencias.
  template <class T>
  T MaxHeap<T>::pop(){
    T value = data[0];
    std::swap(data[0],data[size-1]);
    std::swap(occurences[0],occurences[size-1]);
    data.erase(data.begin()+size-1);
    occurences.erase(occurences.begin()+size-1);
    size--;

    int i = size/2;

    while (i >= 0){
      acomodaAbajo(i);
      i--;
    }
    
    return value;
  }

  // Regresa el número de veces que llegó duplicada la llave en root
  template <class T>
  int MaxHeap<T>::getTopOccurence(){
    return occurences[0];
  }

  // Recorremos el "árbol" desde la raíz hasta las hojas para encontrar una llave
  // en caso de que exista. Es una función recursiva que va visitando los hijos uno por uno hasta llegar a las
  // hojas. O(n)
  template <class T>
  int MaxHeap<T>::checkDupes(T key, int pos) {
    int val;

    if(pos >= size) {
      return -1;
    }

    if(compareIP(key, data[pos]) == 0) {
      return pos;
    }

    val = checkDupes(key, left(pos));
    if(val != -1) return val;
    val = checkDupes(key, right(pos));
    if(val != -1) return val;
    
    return -1;
  }

  // Usamos este código más de una vez ahora que tenemos el control de duplicados, así que lo ponemos en
  // su propia función para llamarlo las veces que lo necesitemos
  template <class T>
  void MaxHeap<T>::repair(int i) {
    while (i >= 0 && occurences[parent(i)] < occurences[i]) {
      std::swap(data[i], data[parent(i)]);
      std::swap(occurences[i], occurences[parent(i)]);
      i = parent(i);
    }
  }

#endif