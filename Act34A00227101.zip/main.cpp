#include <iostream>
#include <math.h>
#include <string.h>
#include <vector>
#include <fstream>
#include "metodos.h"
#include "MaxHeap.h"
using namespace std;

int main() {

  vector<Log> logVector;
  vector<vector<int>> ipVector;
  
  data(logVector, ipVector);

  heapSort(logVector, logVector.size());

  ofstream file;
  file.open("bitacora_ordenada.txt");

  if(!file.is_open()) {
    cerr << "Could not open file.";
    return -1;
  }

  for(Log log : logVector) {
      file << log.ip[0] << "." << log.ip[1] << "." << log.ip[2] << "." << log.ip[3] << ":" << log.port << " " << log.month << " " << log.day << " " << log.hour << " " << log.logMsg << endl;
  }

  file.close();

  logVector.clear();

  MaxHeap heap = MaxHeap<vector<int>>(ipVector.size() + 1);

  int i = 0;

  for(vector<int> ip : ipVector) {
    heap.push(ip);
    i++;
  }

  int size = heap.getSize();

  int sum = 0;

  file.open("ips_con_mayor_acceso.txt");

  if(!file.is_open()) {
    cerr << "Could not open file.";
    return -1;
  }

  for(int i = 0; i < size; i++) {
    int occurences = heap.getTopOccurence();
    vector<int> ip = heap.pop();

    file << ip[0] << "." << ip[1] << "." << ip[2] << "." << ip[3] << " -- " << occurences << endl;

    if(i < 5)
      cout << ip[0] << "." << ip[1] << "." << ip[2] << "." << ip[3] << " -- " << occurences << endl;
  }

  file.close();

  return 0;
}