#ifndef _METODOS_H_
#define _METODOS_H_

  #include<iostream>
  using namespace std;
  
  class Log {
    public:
      time_t timestamp;
      string month;
      string day;
      string hour;
      vector<int> ip;
      string port;
      string logMsg;
  };

  void data(vector<Log> &logVector, vector<vector<int>> &ipVector){ 
    string bitacora = "bitacoraHeap.txt";
    ifstream data(bitacora.c_str());

    if(!data) {
      std:cerr << "Could not open file.";
      return;
    }
    
    string linea;
    int pos;
    string mes, dia, horas, minutos, segundos, ip, port;
    vector<int> ip_v;

    while(getline(data, linea)) {
      pos = 0;
      ip_v.clear();

      mes = linea.substr(pos, linea.find(' ', pos) - pos);
      //cout << mes << endl;
      pos += mes.length() + 1;
      dia = linea.substr(pos, linea.find(' ', pos) - pos);
      //cout << dia << endl;
      pos += dia.length() + 1;
      horas = linea.substr(pos, linea.find(':', pos) - pos);
      //cout << horas << endl;
      pos += horas.length() + 1;
      minutos = linea.substr(pos, linea.find(':', pos) - pos);
      //cout << minutos << endl;
      pos += minutos.length() + 1;
      segundos = linea.substr(pos, linea.find(' ', pos) - pos);
      //cout << segundos << endl;
      pos += segundos.length() + 1;

      ip = linea.substr(pos, linea.find('.', pos) - pos);
      pos += ip.length() + 1;
      ip_v.push_back(stoi(ip));
      ip = linea.substr(pos, linea.find('.', pos) - pos);
      pos += ip.length() + 1;
      ip_v.push_back(stoi(ip));
      ip = linea.substr(pos, linea.find('.', pos) - pos);
      pos += ip.length() + 1;
      ip_v.push_back(stoi(ip));
      ip = linea.substr(pos, linea.find(':', pos) - pos);
      pos += ip.length() + 1;
      ip_v.push_back(stoi(ip));

      port = linea.substr(pos, linea.find(' ', pos) - pos);
      pos += port.length() + 1;
      // Para el mensaje del log, nomás agarramos la posició inicial de la IP, agregamos la longitud de la IP,
      // y agarramos todo el resto del string.
      string msg = linea.substr(pos, linea.find('\n'));

      Log log ;
      log.month = mes;
      log.day = dia;
      log.hour = horas + ":" + minutos + ":" + segundos;
      log.ip = ip_v;
      log.port = port;
      log.logMsg = msg;

      logVector.push_back(log);
      ipVector.push_back(ip_v);
    }

    data.close();
    return;
  }

  int compareIP(vector<int> ip_1, vector<int> ip_2) {

    if(std::equal(begin(ip_1), end(ip_1), begin(ip_2), end(ip_2))) {
      return 0; // 0 son iguales
    } else if(ip_1[0] > ip_2[0]) {
      return 1; // 1 significa que la primera ipe tiene un valor mayor
    } else if(ip_1[0] < ip_2[0]) {
      return 2; // 2 significa que la segunda ip es mayor
    } else if(ip_1[1] > ip_2[1]) {
      return 1;
    } else if(ip_1[1] < ip_2[1]) {
      return 2;
    } else if(ip_1[2] > ip_2[2]) {
      return 1;
    } else if(ip_1[2] < ip_2[2]) {
      return 2;
    } else if(ip_1[3] > ip_2[3]) {
      return 1;
    } else if(ip_1[3] < ip_2[3]) {
      return 2;
    }

    return -1;
  }

  
  void heapify(vector<Log> &logVector, int n, int i) {
      int largest = i; 
      int l = 2 * i + 1; 
      int r = 2 * i + 2; 
  
      
      if (l < n && compareIP(logVector[l].ip, logVector[largest].ip) == 1)
          largest = l;
  
      
      if (r < n && compareIP(logVector[r].ip, logVector[largest].ip) == 1)
          largest = r;
  
      
      if (largest != i) {
          swap(logVector[i], logVector[largest]);
  
          
          heapify(logVector, n, largest);
      }
  }
 
  // Complejidad de O(nLogn)
  void heapSort(vector<Log> &logVector, int n) {
      
      for (int i = n / 2 - 1; i >= 0; i--)
          heapify(logVector, n, i);
  
      
      for (int i = n - 1; i > 0; i--) {
          
          swap(logVector[0], logVector[i]);
  
          
          heapify(logVector, i, 0);
      }
  }
 
  // A utility function to print array of size n 
  void printArray(vector<vector<int>> &ipVector, int n) {
      for (int i = 0; i < n; ++i)
          cout << ipVector[i][0] << "." << ipVector[i][1] << "." << ipVector[i][2] << "." << ipVector[i][3] << ", ";
      cout << "\n";
  }
#endif // _METODOS_H_