/*
Jesús Julián Madrid Castro
A00227101
ITC
Profesor Dr. Eduardo Arturo Rodríguez Tello
*/
#include <iostream>
#include <math.h>
#include <string.h>
#include <vector>
#include <fstream>
#include "dateTime.h"
using namespace std;

class Log {
  public:
    time_t timestamp;
    string month;
    string day;
    string hour;
    string ip;
    string logMsg;
};

void data(vector<Log> &logVector){ 
    string bitacora = "bitacora.txt";
    ifstream data(bitacora.c_str());

    if(!data) {
      std:cerr << "Could not open file";
      return;
    }
    
    string linea;

    while(getline(data, linea)) {
        // Pasamos los substrings que necesita datetime para regresar un timestamp
        dateTime date = dateTime(linea.substr(0,3), 
                            stoi(linea.substr(4,2)), 
                            stoi(linea.substr(7,2)),
                            stoi(linea.substr(10,2)),
                            stoi(linea.substr(13,2)));
        
        time_t dt = date.getDate();
        // Para encontrar IP empezamos de posición 16, luego buscamos la posición del primer espacio
        // a partir del índice 16, y restamos 16 que es el índice del que empezamos.
        string ip = linea.substr(16, linea.find(' ', 16) - 16);
        // Para el mensaje del log, nomás agarramos la posició inicial de la IP, agregamos la longitud de la IP,
        // y agarramos todo el resto del string.
        string msg = linea.substr(17 + ip.length(), linea.find('\n'));

        Log log ;
        log.timestamp = dt;
        log.month = linea.substr(0,3);
        log.day = linea.substr(4,2);
        log.hour = linea.substr(7,8);
        log.ip = ip;
        log.logMsg = msg;

        logVector.push_back(log);
    }

    data.close();
    return;
}



int busquedaBinaria(vector <Log> &data,int l, int r, time_t key){
  //Implementacion de Busqueda Binaria Recursiva
  int m;
  if (l > r) return -1;      
  m = l + (r -l)/2;
  //(*compara)++;
  if (key == data[m].timestamp) return m;
  else if (key < data[m].timestamp) 
      return busquedaBinaria(data, l, m - 1, key);
  else
    return  busquedaBinaria(data, m + 1, r, key);
}

void merge(vector <Log> &data, int l, int m, int r) {
  //Une los elementos previamente dividios por ordena Merge
  
  vector<Log> temp; //En este vector se almacenan las dos mitades ya ordenadas
  
  int i, j;
  i = l;
  j = m+1;

  while (i<=m && j<=r){
    //Mientras falta alguna mitad sin copiar

    //(*compara)++;
    //(*swap)++;

    //Agrega el elemento menor
	  if (data[i].timestamp <= data[j].timestamp) {
			temp.push_back(data[i]);
			++i;
		}
		else {
			temp.push_back(data[j]);
			++j;
		}
  }

  //Agrega los elementos que hayan restado en alguna mitad
  while (i <= m) {
		temp.push_back(data[i]);
		++i;
	}

	while (j <= r) {
		temp.push_back(data[j]);
		++j;
	}

	for (int i = l; i <= r; ++i)
		data[i] = temp[i - l];
}

//Complejidad: O(n log n)
void ordenaMerge(vector <Log> &data, int l, int r) {
  //Implementación del Método de ordenamiento Merge (Merge Sort)

  //*compara = 0;
  //*swap = 0;

  if(l>=r){
    return;
  }
  int m;
  m = (l+r)/2; //Encuentra punto medio
  ordenaMerge(data, l, m); //mitad izquierda
  ordenaMerge(data, m+1, r);  //mitad bien derecha
  merge(data,l, m, r); //fusion mitades
}

int main() {

  vector<Log> logVector;
    
    data(logVector);

    //int compara = 0, swap = 0;

    ordenaMerge(logVector, 0, logVector.size() - 1);

    ofstream file;
    file.open("bitacora_ordenada.txt");

    for(Log log : logVector) {
        file << log.month << " " << log.day << " " << log.hour << " " << log.ip << " " << log.logMsg << endl;
    }

    file.close();
    string mes, mes1;
    int dia, hora, min, seg, dia1, hora1, min1, seg1;

    cout<<" Fecha de inicio: "<<endl;
    cin>>mes;
    cin>>dia;
    cin>>hora;
    cin>>min;
    cin>>seg;

    cout<<" Fecha de fin: "<<endl;
    cin>>mes1;
    cin>>dia1;
    cin>>hora1;
    cin>>min1;
    cin>>seg1;



    int start = busquedaBinaria(logVector, 0, logVector.size() - 1, dateTime(mes, dia, hora, min, seg).getDate());
    
    int end = busquedaBinaria(logVector, 0, logVector.size() - 1, dateTime(mes1, dia1, hora1, min1, seg1).getDate());
/*
    int start2 = busquedaBinaria(logVector, 0, logVector.size() - 1, dateTime("Oct", 26, 13, 37, 41).getDate()); 
    int end2 = busquedaBinaria(logVector, 0, logVector.size() - 1, dateTime("Oct", 30, 23, 48, 41).getDate()); 
*/
    while(start <= end) {
        cout << logVector[start].month << " " << logVector[start].day << " " << logVector[start].hour << " " << logVector[start].ip << " " << logVector[start].logMsg << endl;
        start++;
    }
    
    return 0;
}