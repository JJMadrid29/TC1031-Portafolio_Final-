#ifndef _DOUBLELINKEDLIST_H_
#define _DOUBLELINKEDLIST_H_

  #include <climits>
  #include "Node.h"

  template <class T>
  class DoubleLinkedList {
      private:
        Node<T>* head;
        Node<T>* tail;
        int numElements;

      public:
        DoubleLinkedList();
        ~DoubleLinkedList();
        int getNumElements();
        void printList();
        void addFirst(T value);
        void addLast(T value);
        
        T getData(int position);
        Node<T>* getNode(int position); // AGREGADO
        void updateData(T value, T newValue);
        void updateAt(int position, T newValue);
        int findData(T value);
        T operator[](int position);
        
  };

  template<class T>
  DoubleLinkedList<T>::DoubleLinkedList() {
      std::cout << "--->Creando una lista vacia " << this << std::endl;
      head = NULL;
      tail = NULL;
      numElements = 0;
  }
  
  template<class T>
  DoubleLinkedList<T>::~DoubleLinkedList() {
    std::cout << "--->Liberando memoria de la lista " << this << std::endl;
    Node<T> *p, *q;
    p = head;
    while (p != NULL) {
      q = p->next;
      delete p;
      p = q;
    }
    head = NULL;
    tail = NULL;
    numElements = 0;
  }
 
  template<class T>
  int DoubleLinkedList<T>::getNumElements() {
    return numElements;
  }
  template<class T>
  void DoubleLinkedList<T>::printList() {
    Node<T> *ptr = head;
    if( ptr != NULL){
      while (ptr != NULL) {
          std::cout << ptr->data.month << " " << ptr->data.day << " " << ptr->data.hour << " " << ptr->data.ip << " " << ptr->data.logMsg << "\n";
          ptr = ptr->next;
      }
    } else std::cout<<"No hay elementos en la lista";
    std::cout << std::endl;
  }

  template<class T>
  void DoubleLinkedList<T>::addFirst(T value) {
    Node<T> *newNode = new Node<T>(value);
    // Si la lista esta vacia 
    if (head == NULL) {
      head = newNode;
      tail = newNode;
    }
    else {
      newNode->next = head;
      head->prev = newNode;
      head = newNode;
    }
    numElements++;
  }
  
  template<class T>
  void DoubleLinkedList<T>::addLast(T value) {
    // La lista esta vacia
    if (head == NULL) {
      addFirst(value);
    }
    else {
      Node<T> *newNode = new Node<T>(value);
      tail->next = newNode;
      newNode->prev = tail;
      tail = newNode;
      numElements++;
    }    
  }
  
  template<class T>
  T DoubleLinkedList<T>::getData(int position) {
    T f;
    if (position < 0 || position >= numElements) {
      std::cout << "Indice fuera de rango" << std::endl;
      return f;
    }
    else {
      if (position == 0)
        return head->data;
      Node<T> *p = head;
      int index = 0;
      while (p != NULL) {
        if (index == position)
          return p->data;
        index++;
        p = p->next;
      }
      return f;
    }
  }
  
  template<class T>   
  Node<T>* DoubleLinkedList<T>::getNode(int position) {
    Node<T> *n;
    if (position < 0 || position >= numElements) {
      std::cout << "Indice fuera de rango" << std::endl;
      return n;
    } else {
      if (position == 0)
        return head;
      Node<T> *p = head;
      int index = 0;
      while (p != NULL) {
        if (index == position)
          return p;
        index++;
        p = p->next;
      }
      return n;
    }
  }

  template<class T>
  void DoubleLinkedList<T>::updateData(T value, T newValue){
    //Actualizar un valor determinado
    Node<T> *p;
    p = head;
    
      // buscar valor en la lista
      while (p->next != NULL && p->data != value) {
        p = p->next;
      }
      // Si existe value
      if (p->data == value){
        p->data = newValue;
      } else {
        throw "Out_Of_Range";
      }
  }
 
  
  template<class T>
  void DoubleLinkedList<T>::updateAt(int position, T newValue) {
    //Actualiza en una posición determinada
    if (position < 0 || position >= numElements) {
      throw "Out_Of_Range";
    }
    else {
      int index = 0;
      Node<T> *p = head;
      while (p->next != NULL && index<position){
        p = p->next;
        index++;
      }

      if(index == position){
        p->data = newValue;
      }
    }
  }


  template<class T>
  int DoubleLinkedList<T>::findData(T value){
    //Busca la posición de un valor determinado
    Node<T> *p;
    p = head;
    int cont = 0;
    // head existe y contiene el valor a borrar
    if (p != NULL && p->data == value) {
      return 0;
    }
    else {
      // buscar valor en la lista
      while (p->next != NULL && p->data != value) {
        p = p->next;
        cont++;
      }
      // Si existe value
      if (p->data == value){
        return cont;
      }
      
      return -1;
    }
  }


  template<class T>
  T DoubleLinkedList<T>::operator[](int position){
    //Regresa el valor de una posición determinada
     if (position < 0 || position >= numElements) {
      throw "Out_Of_Range";
    }
    else {
      int index = 0;
      Node<T> *p = head;
      while (index<position){
        p = p->next;
        index++;
      }

      return p->data;
    }
  }

#endif // _DOUBLELINKEDLIST_H_