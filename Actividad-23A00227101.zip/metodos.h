#ifndef _METODOS_H_
#define _METODOS_H_

  #include<iostream>
  using namespace std;
  
  class Log {
    public:
      time_t timestamp;
      string month;
      string day;
      string hour;
      string ip;
      string logMsg;
  };

  void data(DoubleLinkedList<Log> &logList){ 
      string bitacora = "bitacora.txt";
      ifstream data(bitacora.c_str());

      if(!data) {
        std:cerr << "Could not open file";
        return;
      }
      
      string linea;

      while(getline(data, linea)) {
          // Pasamos los substrings que necesita datetime para regresar un timestamp
          dateTime date = dateTime(linea.substr(0,3), 
                              stoi(linea.substr(4,2)), 
                              stoi(linea.substr(7,2)),
                              stoi(linea.substr(10,2)),
                              stoi(linea.substr(13,2)));
          
          time_t dt = date.getDate();
          // Para encontrar IP empezamos de posición 16, luego buscamos la posición del primer espacio
          // a partir del índice 16, y restamos 16 que es el índice del que empezamos.
          string ip = linea.substr(16, linea.find(' ', 16) - 16);
          // Para el mensaje del log, nomás agarramos la posició inicial de la IP, agregamos la longitud de la IP,
          // y agarramos todo el resto del string.
          string msg = linea.substr(17 + ip.length(), linea.find('\n'));

          Log log ;
          log.timestamp = dt;
          log.month = linea.substr(0,3);
          log.day = linea.substr(4,2);
          log.hour = linea.substr(7,8);
          log.ip = ip;
          log.logMsg = msg;

          logList.addLast(log);
      }

      data.close();
      return;
  }

  int busquedaBinaria(DoubleLinkedList <Log> &data,int l, int r, time_t key){
    //Implementacion de Busqueda Binaria Recursiva
    int m;
    if (l > r) return -1;      
    m = l + (r -l)/2;

    if (key == data[m].timestamp) return m;
    else if (key < data[m].timestamp) 
        return busquedaBinaria(data, l, m - 1, key);
    else
      return  busquedaBinaria(data, m + 1, r, key);
  }

  void merge(DoubleLinkedList <Log> &data, int l, int m, int r) {
    //Une los elementos previamente dividios por ordena Merge
    Queue<Log> temp; //En este queue se almacenan las dos mitades ya ordenadas
    
    int i, j;
    i = l;
    j = m+1;

    Node<Log> *nodei = data.getNode(i);
    Node<Log> *nodej = data.getNode(j);

    while (i<=m && j<=r){
      //Mientras falta alguna mitad sin copiar

      //Agrega el elemento menor
      if (nodei->data.timestamp <= nodej->data.timestamp) {
        temp.enqueue(nodei->data);
        nodei = nodei->next;
        ++i;
      }
      else {
        temp.enqueue(nodej->data);
        nodej = nodej->next;
        ++j;
      }
    }

    //Agrega los elementos que hayan restado en alguna mitad
    while (i <= m) {
      temp.enqueue(nodei->data);
      nodei = nodei->next;
      ++i;   
    }

    while (j <= r) {
      temp.enqueue(nodej->data);
      nodej = nodej->next;
      ++j;
    }

    for (int i = l; i <= r; ++i)
      data.updateAt(i, temp.dequeue());

    /*std::cout << "Finished sorting from " << l << " to " << r << "\n";*/  //control para ver que se haga el sort
  }

  //Complejidad: O(n log n)
  void ordenaMerge(DoubleLinkedList<Log> &data, int l, int r) {
    //Implementación del Método de ordenamiento Merge (Merge Sort)

    if(l>=r){
      return;
    }
    int m;
    m = (l+r)/2; //Encuentra punto medio
    ordenaMerge(data, l, m); //mitad izquierda
    ordenaMerge(data, m+1, r);  //mitad bien derecha
    merge(data,l, m, r); //fusion mitades
  }
#endif // _METODOS_H_