/*
Jesús Julián Madrid Castro
A00227101
ITC
Profesor Dr. Eduardo Arturo Rodríguez Tello
*/
#include <iostream>
#include <math.h>
#include <string.h>
#include <fstream>
#include "dateTime.h"
#include "DoubleLinkedList.h"
#include "Queue.h"
#include "Node.h"
#include "metodos.h"
using namespace std;




int main() {

  
  std::cout << "Called by main";
  DoubleLinkedList<Log> logList;
    
    data(logList);
    
    ordenaMerge(logList, 0, logList.getNumElements() - 1);
    
    ofstream file;
    file.open("bitacora_ordenada.txt");

    int i = 0;
    Log log;

    Node<Log> *node = logList.getNode(0);

    for(;i < logList.getNumElements();) {
        log = node->data;
        file << log.month << " " << log.day << " " << log.hour << " " << log.ip << " " << log.logMsg << endl;
        node = node->next;
        i++;
    }

    file.close();
    string mes, mes1;
    int dia, hora, min, seg, dia1, hora1, min1, seg1;

    cout<<" Fecha de inicio: "<<endl;
    cout<<" Introduzca Mes(ejemplo: Aug, Jun, Oct): "<<endl;cin>>mes;
    cout<<" Introduzca Dia (formato de 2 dijitos: 01,11, 23): "<<endl;cin>>dia;
    cout<<" Introduzca Hora (formato de 2 dijitos: 01, 15, 21): "<<endl;cin>>hora;
    cout<<" Introduzca Minuto (formato de 2 dijitos: 03, 18, 46): "<<endl;cin>>min;
    cout<<" Introduzca Segundos (formato de 2 dijitos: 00, 40, 56): "<<endl;cin>>seg;

    cout<<" Fecha de fin: "<<endl;
    cout<<" Introduzca Mes(ejemplo: Aug, Jun, Oct): "<<endl;cin>>mes1;
    cout<<" Introduzca Dia (formato de 2 dijitos: 01,11, 23): "<<endl;cin>>dia1;
    cout<<" Introduzca Hora (formato de 2 dijitos: 01, 15, 21): "<<endl;cin>>hora1;
    cout<<" Introduzca Minuto (formato de 2 dijitos: 03, 18, 46): "<<endl;cin>>min1;
    cout<<" Introduzca Segundos (formato de 2 dijitos: 00, 40, 56): "<<endl;cin>>seg1;

    int start = busquedaBinaria(logList, 0, logList.getNumElements() - 1, dateTime(mes, dia, hora, min, seg).getDate());
    
    int end = busquedaBinaria(logList, 0, logList.getNumElements() - 1, dateTime(mes1, dia1, hora1, min1, seg1).getDate());

    while(start <= end) {
        cout << logList[start].month << " " << logList[start].day << " " << logList[start].hour << " " << logList[start].ip << " " << logList[start].logMsg << endl;
        start++;
    }
    
    return 0;
}